/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe.part2;

/**
 *
 * @author RC_Student_lab
 */
public class Task {
    private String name;
    private int number;
    private String description;
    private String developer;
    private double duration; 
    private String status;
    private static int taskCount= 0;//keeps track of total task 
    
    public Task(String name, String description, String developer, double duration,String status){
        
        this.name=name;
        this.description=description;
        this.developer=developer;
        this.duration=duration;
        this.number=taskCount++;
        
    }

    Task(String test_Task, String description, String robyn_Harrisonn, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    //Task check 
    public boolean checkTaskDescription(){
      return description.length()<=50;
    }
    
    public String createTaskID(){
        return name.substring(0,2).toUpperCase()+"."+number+"."+developer.substring(developer.length()-3).toUpperCase();
        
        
    }
    public String printTaskDetails(){
        return String.format("%s,%s,%d,%s,%s,%s,%".1f hours",status,developer,number,name,description,createTaskID(),duration);
    }
    
    public static int returnTotalHours(Task[]task){
        double totalHours=0;
        for(Task task:task){
        totalHours +=task.duration;           
        
        }
       
        return (int) Math.ceil(totalHours);//Round up to the nearest
    }
}

