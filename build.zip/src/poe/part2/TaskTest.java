/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe.part2;

/**
 *
 * @author RC_Student_lab
 */ 
public class TaskTest {
    public void
    testTaskDescriptionLength_Success(){
        String description="This descroption is less than 50 characters";
        Task task=new Task("Test Task"),description,"Robyn Harrisonn",5"To Do");
        
    }
}
